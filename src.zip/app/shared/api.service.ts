import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private _http:HttpClient) { }

  //create
  poststudent(data:any){
    return this._http.post<any>("http://localhost:3000/users",data).
    pipe(map((res:any)=>{
      return res;
    }))
  }


  //get
  getstudent(){
    return this._http.get<any>("http://localhost:3000/users")
    .pipe(map((res:any)=>{
      return res;
    }))
  }

  //update
  updatestudent(data:any,id:number){
    return this._http.put("http://localhost:3000/users/"+id,data)
    .pipe(map((res:any)=>{
      return res;
    }))
  }

  //delete
  deletestudent(id:number){
    return this._http.delete<any>("http://localhost:3000/users/"+id)
    .pipe(map((res:any)=>{
      return res;
    }))
  }
}
