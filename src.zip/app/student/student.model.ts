export class studentdata{
  id:number = 0;
  name:string = '';
  email:string = '';
  mobile:string= '';
}
