import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { studentdata } from './student.model';
import { ApiService } from '../shared/api.service';


@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit{

id: number;
name: string;
email: string;
mobile: string;

showadd!:boolean;
showupdate!:boolean;
studentmodelobj:studentdata=new studentdata

formValue!:FormGroup;
allstudentdata:any;

  constructor(private formBuilder:FormBuilder, private api:ApiService) { }

  ngOnInit(): void {
    this.formValue = this.formBuilder.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      mobile: ['', Validators.required]
    })
    this.getdata()
  }
  //to hide on add
add() {
this.showadd=true;
this.showupdate=false;
}
//to hide on edit
edit(data:any) {
this.showadd=false;
this.showupdate=true;
this.studentmodelobj.id= data.id;

this.formValue.controls['name'].setValue(data.name)
this.formValue.controls['email'].setValue(data.email)
this.formValue.controls['mobile'].setValue(data.mobile)
}

//update
update(){
  this.studentmodelobj.name = this.formValue.value.name;
  this.studentmodelobj.email = this.formValue.value.email;
  this.studentmodelobj.mobile = this.formValue.value.mobile;

  this.api.updatestudent(this.studentmodelobj,this.studentmodelobj.id).subscribe(res=>{
    this.formValue.reset();
    this.getdata();
    alert("Record updated successfully");
  },
  err=>{
    alert("Something went wrong!");
  }
)
}


addstudent(){
  this.studentmodelobj.name = this.formValue.value.name;
  this.studentmodelobj.email = this.formValue.value.email;
  this.studentmodelobj.mobile = this.formValue.value.mobile;

  this.api.poststudent(this.studentmodelobj).subscribe(res=>{
    console.log(res)
    this.formValue.reset()
    this.getdata()
    alert("Record Added successfully")
  },
  err=>{
    alert("Something went wrong!")
  })
}

//getdata
getdata(){
this.api.getstudent()
.subscribe(res=>{
  this.allstudentdata = res;
})
}
//delete
deletestudent(data:any){
  if(confirm('Are you sure to delete?'))
  this.api.deletestudent(data.id)
  .subscribe(res=>{
    alert("Record deleted successfully!");
    this.getdata();
  })
}



}
